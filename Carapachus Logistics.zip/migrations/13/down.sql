
ALTER TABLE embarques DROP COLUMN id_usuario_cliente;
