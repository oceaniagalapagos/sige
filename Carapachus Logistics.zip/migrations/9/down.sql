
DROP INDEX idx_usuarios_rol;
DROP INDEX idx_usuarios_mocha_id;
DROP TABLE usuarios_app;
