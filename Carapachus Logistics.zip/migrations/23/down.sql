
ALTER TABLE productos_embarque DROP COLUMN id_calendario_embarque;
