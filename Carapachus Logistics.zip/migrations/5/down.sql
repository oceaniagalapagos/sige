
DROP TABLE barcos;
