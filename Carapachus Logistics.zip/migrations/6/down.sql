
DROP INDEX idx_calendario_barco;
DROP INDEX idx_calendario_fecha;
DROP TABLE calendario_embarques;
