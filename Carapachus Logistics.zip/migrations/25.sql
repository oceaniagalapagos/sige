INSERT INTO tipos_documento (nombre_tipo, descripcion) VALUES 
  ('Factura', 'Factura comercial del producto o servicio'),
  ('Guía de despacho', 'Guía de despacho o remisión'),
  ('Certificado', 'Certificados sanitarios, fitosanitarios u otros'),
  ('Fotografía', 'Registro fotográfico de productos o embarques'),
  ('Otro', 'Otros tipos de documentos');
