
DROP INDEX idx_embarques_estado;
DROP INDEX idx_embarques_cliente;
DROP INDEX idx_embarques_codigo;
DROP TABLE embarques;
