
DROP INDEX idx_embarques_servicios_embarque;
DROP TABLE embarques_servicios;
