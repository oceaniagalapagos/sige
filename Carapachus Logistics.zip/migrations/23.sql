
ALTER TABLE productos_embarque ADD COLUMN id_calendario_embarque INTEGER;
