
DROP INDEX idx_logs_fecha;
DROP INDEX idx_logs_usuario;
DROP TABLE logs_sistema;
