
DROP TABLE tipos_embalaje;
DROP TABLE tipos_servicio;
