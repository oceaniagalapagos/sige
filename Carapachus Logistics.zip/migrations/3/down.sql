
DROP INDEX idx_productos_codigo_qr;
DROP INDEX idx_productos_embarque;
DROP TABLE productos_embarque;
