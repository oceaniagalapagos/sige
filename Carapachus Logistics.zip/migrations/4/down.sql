
DROP INDEX idx_documentos_embarque;
DROP TABLE documentos;
