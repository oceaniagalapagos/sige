DELETE FROM tipos_documento WHERE nombre_tipo IN ('Factura', 'Guía de despacho', 'Certificado', 'Fotografía', 'Otro');
