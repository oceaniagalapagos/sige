
ALTER TABLE barcos DROP COLUMN id_tipo_transporte;

DROP TABLE tipos_transporte;
