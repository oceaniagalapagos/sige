
ALTER TABLE puertos DROP COLUMN id_ubicacion;
DROP TABLE ubicaciones;
