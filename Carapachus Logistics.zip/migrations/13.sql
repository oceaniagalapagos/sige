
ALTER TABLE embarques ADD COLUMN id_usuario_cliente TEXT;
