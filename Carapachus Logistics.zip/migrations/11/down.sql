
DROP INDEX idx_tipos_productos_nombre;
DROP TABLE tipos_productos;
