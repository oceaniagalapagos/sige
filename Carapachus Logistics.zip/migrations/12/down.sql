
ALTER TABLE calendario_embarques DROP COLUMN tipo_transporte;
ALTER TABLE calendario_embarques DROP COLUMN fecha_arribo_puerto;
ALTER TABLE calendario_embarques DROP COLUMN id_puerto_destino;
