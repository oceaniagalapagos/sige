
DROP TABLE tipos_documento;
