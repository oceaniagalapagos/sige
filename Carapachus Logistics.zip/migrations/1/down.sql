
DROP INDEX idx_clientes_email;
DROP TABLE clientes;
