
DROP INDEX idx_puertos_isla;
DROP TABLE puertos;
