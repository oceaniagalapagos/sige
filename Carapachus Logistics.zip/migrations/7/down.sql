
DROP INDEX idx_config_tipo_servicio;
DROP TABLE configuracion_costos;
